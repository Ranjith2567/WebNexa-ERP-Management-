const mongoose = require("mongoose");

const User = require("../models/User");
const Product = require("../models/Product");
const Customer = require("../models/Customer");
const Supplier = require("../models/Supplier");
const Stock = require("../models/Stock");
const SalesInvoice = require("../models/SalesInvoice");
const PurchaseInvoice = require("../models/PurchaseInvoice");
const Expense = require("../models/Expense");
const LedgerEntry = require("../models/LedgerEntry");

// =====================================================
// GET DASHBOARD SUMMARY
// =====================================================

const getDashboardSummary = async (req, res) => {
    try {
        const {
            company,
            branch,
        } = req.query;

        // =================================================
        // VALIDATION
        // =================================================

        if (!company) {
            return res.status(400).json({
                success: false,
                message: "Company is required.",
            });
        }

        if (!mongoose.Types.ObjectId.isValid(company)) {
            return res.status(400).json({
                success: false,
                message: "Invalid company ID.",
            });
        }

        if (
            branch &&
            !mongoose.Types.ObjectId.isValid(branch)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid branch ID.",
            });
        }

        const companyId =
            new mongoose.Types.ObjectId(company);

        const branchId = branch
            ? new mongoose.Types.ObjectId(branch)
            : null;

        // =================================================
        // COMMON FILTERS
        // =================================================

        const userMatch = {
            company: companyId,
            isActive: true,
        };

        const productMatch = {
            company: companyId,
            isActive: true,
        };

        const customerMatch = {
            company: companyId,
            isActive: true,
        };

        const supplierMatch = {
            company: companyId,
            isActive: true,
        };

        const stockMatch = {
            company: companyId,
            isActive: true,
        };

        // =================================================
        // SALES
        // Only ISSUED invoices are counted as sales
        // =================================================

        const salesMatch = {
            company: companyId,
            status: "ISSUED",
        };

        const purchaseMatch = {
            company: companyId,
        };

        const expenseMatch = {
            company: companyId,
        };

        const ledgerMatch = {
            company: companyId,
        };

        // =================================================
        // BRANCH FILTER
        // =================================================

        if (branchId) {
            userMatch.branch = branchId;
            productMatch.branch = branchId;
            customerMatch.branch = branchId;
            supplierMatch.branch = branchId;
            stockMatch.branch = branchId;
            salesMatch.branch = branchId;
            purchaseMatch.branch = branchId;
            expenseMatch.branch = branchId;
            ledgerMatch.branch = branchId;
        }

        // =================================================
        // RUN ALL DASHBOARD QUERIES IN PARALLEL
        // =================================================

        const [
            totalUsers,
            totalEmployees,
            totalProducts,
            totalCustomers,
            totalSuppliers,
            stockSummary,
            salesSummary,
            purchaseSummary,
            expenseSummary,
            financeSummary,
        ] = await Promise.all([

            // =============================================
            // TOTAL USERS
            // =============================================

            User.countDocuments(userMatch),

            // =============================================
            // TOTAL EMPLOYEES
            // =============================================

            User.countDocuments({
                ...userMatch,
                role: "EMPLOYEE",
            }),

            // =============================================
            // TOTAL PRODUCTS
            // =============================================

            Product.countDocuments(productMatch),

            // =============================================
            // TOTAL CUSTOMERS
            // =============================================

            Customer.countDocuments(customerMatch),

            // =============================================
            // TOTAL SUPPLIERS
            // =============================================

            Supplier.countDocuments(supplierMatch),

            // =============================================
            // STOCK SUMMARY
            // =============================================

            Stock.aggregate([
                {
                    $match: stockMatch,
                },

                {
                    $lookup: {
                        from: "products",
                        localField: "product",
                        foreignField: "_id",
                        as: "product",
                    },
                },

                {
                    $unwind: {
                        path: "$product",
                        preserveNullAndEmptyArrays: false,
                    },
                },

                {
                    $match: {
                        "product.isActive": true,
                    },
                },

                {
                    $addFields: {
                        availableQuantity: {
                            $subtract: [
                                {
                                    $ifNull: [
                                        "$quantity",
                                        0,
                                    ],
                                },
                                {
                                    $ifNull: [
                                        "$reservedQuantity",
                                        0,
                                    ],
                                },
                            ],
                        },

                        stockValue: {
                            $multiply: [
                                {
                                    $ifNull: [
                                        "$quantity",
                                        0,
                                    ],
                                },
                                {
                                    $ifNull: [
                                        "$product.purchasePrice",
                                        0,
                                    ],
                                },
                            ],
                        },
                    },
                },

                {
                    $group: {
                        _id: null,

                        totalQuantity: {
                            $sum: "$quantity",
                        },

                        totalReservedQuantity: {
                            $sum: "$reservedQuantity",
                        },

                        totalAvailableQuantity: {
                            $sum: "$availableQuantity",
                        },

                        totalStockValue: {
                            $sum: "$stockValue",
                        },

                        lowStockItems: {
                            $sum: {
                                $cond: [
                                    {
                                        $and: [
                                            {
                                                $gt: [
                                                    "$availableQuantity",
                                                    0,
                                                ],
                                            },
                                            {
                                                $lte: [
                                                    "$availableQuantity",
                                                    "$minimumStock",
                                                ],
                                            },
                                        ],
                                    },
                                    1,
                                    0,
                                ],
                            },
                        },

                        outOfStockItems: {
                            $sum: {
                                $cond: [
                                    {
                                        $lte: [
                                            "$availableQuantity",
                                            0,
                                        ],
                                    },
                                    1,
                                    0,
                                ],
                            },
                        },

                        overStockItems: {
                            $sum: {
                                $cond: [
                                    {
                                        $and: [
                                            {
                                                $gt: [
                                                    "$maximumStock",
                                                    0,
                                                ],
                                            },
                                            {
                                                $gt: [
                                                    "$quantity",
                                                    "$maximumStock",
                                                ],
                                            },
                                        ],
                                    },
                                    1,
                                    0,
                                ],
                            },
                        },
                    },
                },
            ]),

            // =============================================
            // SALES SUMMARY
            // =============================================

            SalesInvoice.aggregate([
                {
                    $match: salesMatch,
                },

                {
                    $group: {
                        _id: null,

                        // IMPORTANT:
                        // SalesInvoice uses grandTotal
                        // NOT totalAmount

                        totalSales: {
                            $sum: {
                                $ifNull: [
                                    "$grandTotal",
                                    0,
                                ],
                            },
                        },

                        totalInvoices: {
                            $sum: 1,
                        },
                    },
                },
            ]),

            // =============================================
            // PURCHASE SUMMARY
            // =============================================

            PurchaseInvoice.aggregate([
                {
                    $match: purchaseMatch,
                },

                {
                    $group: {
                        _id: null,

                        totalPurchases: {
                            $sum: {
                                $ifNull: [
                                    "$totalAmount",
                                    0,
                                ],
                            },
                        },

                        totalInvoices: {
                            $sum: 1,
                        },
                    },
                },
            ]),

            // =============================================
            // EXPENSE SUMMARY
            // =============================================

            Expense.aggregate([
                {
                    $match: expenseMatch,
                },

                {
                    $group: {
                        _id: null,

                        totalExpenses: {
                            $sum: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },

                        totalExpenseEntries: {
                            $sum: 1,
                        },
                    },
                },
            ]),

            // =============================================
            // FINANCE SUMMARY
            // =============================================

            LedgerEntry.aggregate([
                {
                    $match: ledgerMatch,
                },

                {
                    $group: {
                        _id: null,

                        totalDebit: {
                            $sum: {
                                $ifNull: [
                                    "$debit",
                                    0,
                                ],
                            },
                        },

                        totalCredit: {
                            $sum: {
                                $ifNull: [
                                    "$credit",
                                    0,
                                ],
                            },
                        },
                    },
                },
            ]),
        ]);

        // =================================================
        // NORMALIZE RESULTS
        // =================================================

        const stock = stockSummary[0] || {
            totalQuantity: 0,
            totalReservedQuantity: 0,
            totalAvailableQuantity: 0,
            totalStockValue: 0,
            lowStockItems: 0,
            outOfStockItems: 0,
            overStockItems: 0,
        };

        const sales = salesSummary[0] || {
            totalSales: 0,
            totalInvoices: 0,
        };

        const purchases = purchaseSummary[0] || {
            totalPurchases: 0,
            totalInvoices: 0,
        };

        const expenses = expenseSummary[0] || {
            totalExpenses: 0,
            totalExpenseEntries: 0,
        };

        const finance = financeSummary[0] || {
            totalDebit: 0,
            totalCredit: 0,
        };

        // =================================================
        // PROFIT / NET POSITION
        // =================================================

        const totalSales =
            Number(sales.totalSales || 0);

        const totalPurchases =
            Number(purchases.totalPurchases || 0);

        const totalExpenses =
            Number(expenses.totalExpenses || 0);

        const grossProfit =
            totalSales - totalPurchases;

        const netProfit =
            grossProfit - totalExpenses;

        // =================================================
        // RESPONSE
        // =================================================

        return res.status(200).json({
            success: true,

            data: {
                overview: {
                    totalUsers,
                    totalEmployees,
                    totalProducts,
                    totalCustomers,
                    totalSuppliers,
                },

                sales: {
                    totalSales,
                    totalInvoices:
                        sales.totalInvoices,
                },

                purchases: {
                    totalPurchases,
                    totalInvoices:
                        purchases.totalInvoices,
                },

                expenses: {
                    totalExpenses,
                    totalExpenseEntries:
                        expenses.totalExpenseEntries,
                },

                inventory: {
                    totalQuantity:
                        stock.totalQuantity,

                    totalReservedQuantity:
                        stock.totalReservedQuantity,

                    totalAvailableQuantity:
                        stock.totalAvailableQuantity,

                    totalStockValue:
                        stock.totalStockValue,

                    lowStockItems:
                        stock.lowStockItems,

                    outOfStockItems:
                        stock.outOfStockItems,

                    overStockItems:
                        stock.overStockItems,
                },

                finance: {
                    totalDebit:
                        finance.totalDebit,

                    totalCredit:
                        finance.totalCredit,

                    difference:
                        Number(finance.totalDebit || 0) -
                        Number(finance.totalCredit || 0),
                },

                profitability: {
                    grossProfit,
                    netProfit,
                },
            },
        });

    } catch (error) {
        console.error(
            "Get Dashboard Summary Error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch dashboard summary.",
            error: error.message,
        });
    }
};

// =====================================================
// EXPORT
// =====================================================

module.exports = {
    getDashboardSummary,
};