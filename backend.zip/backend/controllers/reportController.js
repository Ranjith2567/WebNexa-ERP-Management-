const mongoose = require("mongoose");

const SalesInvoice = require("../models/SalesInvoice");
const PurchaseInvoice = require("../models/PurchaseInvoice");
const Stock = require("../models/Stock");
const Expense = require("../models/Expense");

// =====================================================
// GET SALES REPORT
// =====================================================

const getSalesReport = async (req, res) => {
    try {
        const {
            company,
            branch,
            customer,
            salesPerson,
            status,
            paymentStatus,
            fromDate,
            toDate,
            page = 1,
            limit = 20,
        } = req.query;

        // =================================================
        // VALIDATION
        // =================================================

        if (!company) {
            return res.status(400).json({
                success: false,
                message: "Company is required.",
            });
        }

        if (!mongoose.Types.ObjectId.isValid(company)) {
            return res.status(400).json({
                success: false,
                message: "Invalid company ID.",
            });
        }

        if (
            branch &&
            !mongoose.Types.ObjectId.isValid(branch)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid branch ID.",
            });
        }

        if (
            customer &&
            !mongoose.Types.ObjectId.isValid(customer)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid customer ID.",
            });
        }

        if (
            salesPerson &&
            !mongoose.Types.ObjectId.isValid(salesPerson)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid sales person ID.",
            });
        }

        // =================================================
        // PAGINATION
        // =================================================

        const currentPage = Math.max(
            Number(page) || 1,
            1
        );

        const currentLimit = Math.min(
            Math.max(Number(limit) || 20, 1),
            100
        );

        const skip =
            (currentPage - 1) * currentLimit;

        // =================================================
        // MATCH FILTER
        // =================================================

        const match = {
            company:
                new mongoose.Types.ObjectId(company),
        };

        if (branch) {
            match.branch =
                new mongoose.Types.ObjectId(branch);
        }

        if (customer) {
            match.customer =
                new mongoose.Types.ObjectId(customer);
        }

        if (salesPerson) {
            match.salesPerson =
                new mongoose.Types.ObjectId(salesPerson);
        }

        // =================================================
        // STATUS FILTER
        // =================================================

        if (status) {
            const allowedStatuses = [
                "DRAFT",
                "ISSUED",
                "CANCELLED",
            ];

            if (!allowedStatuses.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid invoice status.",
                });
            }

            match.status = status;
        }

        // =================================================
        // PAYMENT STATUS FILTER
        // =================================================

        if (paymentStatus) {
            const allowedPaymentStatuses = [
                "UNPAID",
                "PARTIALLY_PAID",
                "PAID",
                "OVERDUE",
            ];

            if (
                !allowedPaymentStatuses.includes(
                    paymentStatus
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid payment status.",
                });
            }

            match.paymentStatus =
                paymentStatus;
        }

        // =================================================
        // DATE FILTER
        // =================================================

        if (fromDate || toDate) {
            match.invoiceDate = {};

            if (fromDate) {
                const startDate =
                    new Date(fromDate);

                if (isNaN(startDate.getTime())) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "Invalid fromDate.",
                    });
                }

                startDate.setHours(
                    0,
                    0,
                    0,
                    0
                );

                match.invoiceDate.$gte =
                    startDate;
            }

            if (toDate) {
                const endDate =
                    new Date(toDate);

                if (isNaN(endDate.getTime())) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "Invalid toDate.",
                    });
                }

                endDate.setHours(
                    23,
                    59,
                    59,
                    999
                );

                match.invoiceDate.$lte =
                    endDate;
            }
        }

        // =================================================
        // GET TOTAL COUNT
        // =================================================

        const total =
            await SalesInvoice.countDocuments(
                match
            );

        // =================================================
        // GET REPORT DATA
        // =================================================

        const invoices =
            await SalesInvoice.find(match)
                .populate(
                    "customer",
                    "name email phone"
                )
                .populate(
                    "salesPerson",
                    "name email"
                )
                .populate(
                    "branch",
                    "name code"
                )
                .populate(
                    "salesOrder",
                    "orderNumber"
                )
                .sort({
                    invoiceDate: -1,
                    createdAt: -1,
                })
                .skip(skip)
                .limit(currentLimit)
                .lean();

        // =================================================
        // REPORT SUMMARY
        // =================================================

        const summaryResult =
            await SalesInvoice.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: null,

                        totalInvoices: {
                            $sum: 1,
                        },

                        subtotal: {
                            $sum: {
                                $ifNull: [
                                    "$subtotal",
                                    0,
                                ],
                            },
                        },

                        discountAmount: {
                            $sum: {
                                $ifNull: [
                                    "$discountAmount",
                                    0,
                                ],
                            },
                        },

                        taxableAmount: {
                            $sum: {
                                $ifNull: [
                                    "$taxableAmount",
                                    0,
                                ],
                            },
                        },

                        taxAmount: {
                            $sum: {
                                $ifNull: [
                                    "$taxAmount",
                                    0,
                                ],
                            },
                        },

                        grandTotal: {
                            $sum: {
                                $ifNull: [
                                    "$grandTotal",
                                    0,
                                ],
                            },
                        },

                        paidAmount: {
                            $sum: {
                                $ifNull: [
                                    "$paidAmount",
                                    0,
                                ],
                            },
                        },

                        balanceDue: {
                            $sum: {
                                $ifNull: [
                                    "$balanceDue",
                                    0,
                                ],
                            },
                        },
                    },
                },
            ]);

        const summary =
            summaryResult[0] || {
                totalInvoices: 0,
                subtotal: 0,
                discountAmount: 0,
                taxableAmount: 0,
                taxAmount: 0,
                grandTotal: 0,
                paidAmount: 0,
                balanceDue: 0,
            };

        // =================================================
        // PAYMENT STATUS SUMMARY
        // =================================================

        const paymentStatusSummary =
            await SalesInvoice.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: "$paymentStatus",

                        count: {
                            $sum: 1,
                        },

                        amount: {
                            $sum: {
                                $ifNull: [
                                    "$grandTotal",
                                    0,
                                ],
                            },
                        },
                    },
                },

                {
                    $sort: {
                        _id: 1,
                    },
                },
            ]);

        // =================================================
        // FINAL RESPONSE
        // =================================================

        return res.status(200).json({
            success: true,

            data: {
                invoices,

                summary: {
                    totalInvoices:
                        summary.totalInvoices,

                    subtotal:
                        summary.subtotal,

                    discountAmount:
                        summary.discountAmount,

                    taxableAmount:
                        summary.taxableAmount,

                    taxAmount:
                        summary.taxAmount,

                    grandTotal:
                        summary.grandTotal,

                    paidAmount:
                        summary.paidAmount,

                    balanceDue:
                        summary.balanceDue,
                },

                paymentStatusSummary:
                    paymentStatusSummary.map(
                        (item) => ({
                            paymentStatus:
                                item._id,

                            count:
                                item.count,

                            amount:
                                item.amount,
                        })
                    ),
            },

            pagination: {
                total,
                page: currentPage,
                limit: currentLimit,
                totalPages:
                    Math.ceil(
                        total / currentLimit
                    ),
            },
        });

    } catch (error) {
        console.error(
            "Get Sales Report Error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch sales report.",
            error: error.message,
        });
    }
};

// =====================================================
// GET PURCHASE REPORT
// =====================================================

const getPurchaseReport = async (req, res) => {
    try {
        const {
            company,
            branch,
            supplier,
            purchaseOrder,
            goodsReceipt,
            status,
            paymentStatus,
            fromDate,
            toDate,
            page = 1,
            limit = 20,
        } = req.query;

        // =================================================
        // VALIDATION
        // =================================================

        if (!company) {
            return res.status(400).json({
                success: false,
                message: "Company is required.",
            });
        }

        if (!mongoose.Types.ObjectId.isValid(company)) {
            return res.status(400).json({
                success: false,
                message: "Invalid company ID.",
            });
        }

        if (
            branch &&
            !mongoose.Types.ObjectId.isValid(branch)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid branch ID.",
            });
        }

        if (
            supplier &&
            !mongoose.Types.ObjectId.isValid(supplier)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid supplier ID.",
            });
        }

        if (
            purchaseOrder &&
            !mongoose.Types.ObjectId.isValid(
                purchaseOrder
            )
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid purchase order ID.",
            });
        }

        if (
            goodsReceipt &&
            !mongoose.Types.ObjectId.isValid(
                goodsReceipt
            )
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid goods receipt ID.",
            });
        }

        // =================================================
        // PAGINATION
        // =================================================

        const currentPage = Math.max(
            Number(page) || 1,
            1
        );

        const currentLimit = Math.min(
            Math.max(Number(limit) || 20, 1),
            100
        );

        const skip =
            (currentPage - 1) * currentLimit;

        // =================================================
        // MATCH FILTER
        // =================================================

        const match = {
            company:
                new mongoose.Types.ObjectId(company),
        };

        if (branch) {
            match.branch =
                new mongoose.Types.ObjectId(branch);
        }

        if (supplier) {
            match.supplier =
                new mongoose.Types.ObjectId(supplier);
        }

        if (purchaseOrder) {
            match.purchaseOrder =
                new mongoose.Types.ObjectId(
                    purchaseOrder
                );
        }

        if (goodsReceipt) {
            match.goodsReceipt =
                new mongoose.Types.ObjectId(
                    goodsReceipt
                );
        }

        // =================================================
        // STATUS FILTER
        // =================================================

        if (status) {
            const allowedStatuses = [
                "DRAFT",
                "POSTED",
                "PARTIALLY_PAID",
                "PAID",
                "CANCELLED",
            ];

            if (!allowedStatuses.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid purchase invoice status.",
                });
            }

            match.status = status;
        }

        // =================================================
        // PAYMENT STATUS FILTER
        // =================================================

        if (paymentStatus) {
            const allowedPaymentStatuses = [
                "UNPAID",
                "PARTIALLY_PAID",
                "PAID",
                "OVERDUE",
                "CANCELLED",
            ];

            if (
                !allowedPaymentStatuses.includes(
                    paymentStatus
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid payment status.",
                });
            }

            match.paymentStatus =
                paymentStatus;
        }

        // =================================================
        // DATE FILTER
        // =================================================

        if (fromDate || toDate) {
            match.invoiceDate = {};

            if (fromDate) {
                const startDate =
                    new Date(fromDate);

                if (isNaN(startDate.getTime())) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "Invalid fromDate.",
                    });
                }

                startDate.setHours(
                    0,
                    0,
                    0,
                    0
                );

                match.invoiceDate.$gte =
                    startDate;
            }

            if (toDate) {
                const endDate =
                    new Date(toDate);

                if (isNaN(endDate.getTime())) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "Invalid toDate.",
                    });
                }

                endDate.setHours(
                    23,
                    59,
                    59,
                    999
                );

                match.invoiceDate.$lte =
                    endDate;
            }
        }

        // =================================================
        // GET TOTAL COUNT
        // =================================================

        const total =
            await PurchaseInvoice.countDocuments(
                match
            );

        // =================================================
        // GET REPORT DATA
        // =================================================

        const invoices =
            await PurchaseInvoice.find(match)
                .populate("supplier")
                .populate(
                    "branch",
                    "name code"
                )
                .populate("purchaseOrder")
                .populate("goodsReceipt")
                .sort({
                    invoiceDate: -1,
                    createdAt: -1,
                })
                .skip(skip)
                .limit(currentLimit)
                .lean();

        // =================================================
        // REPORT SUMMARY
        // =================================================

        const summaryResult =
            await PurchaseInvoice.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: null,

                        totalInvoices: {
                            $sum: 1,
                        },

                        subtotal: {
                            $sum: {
                                $ifNull: [
                                    "$subtotal",
                                    0,
                                ],
                            },
                        },

                        discountAmount: {
                            $sum: {
                                $ifNull: [
                                    "$discountAmount",
                                    0,
                                ],
                            },
                        },

                        taxAmount: {
                            $sum: {
                                $ifNull: [
                                    "$taxAmount",
                                    0,
                                ],
                            },
                        },

                        shippingAmount: {
                            $sum: {
                                $ifNull: [
                                    "$shippingAmount",
                                    0,
                                ],
                            },
                        },

                        otherCharges: {
                            $sum: {
                                $ifNull: [
                                    "$otherCharges",
                                    0,
                                ],
                            },
                        },

                        roundOffAmount: {
                            $sum: {
                                $ifNull: [
                                    "$roundOffAmount",
                                    0,
                                ],
                            },
                        },

                        totalAmount: {
                            $sum: {
                                $ifNull: [
                                    "$totalAmount",
                                    0,
                                ],
                            },
                        },

                        paidAmount: {
                            $sum: {
                                $ifNull: [
                                    "$paidAmount",
                                    0,
                                ],
                            },
                        },

                        dueAmount: {
                            $sum: {
                                $ifNull: [
                                    "$dueAmount",
                                    0,
                                ],
                            },
                        },
                    },
                },
            ]);

        const summary =
            summaryResult[0] || {
                totalInvoices: 0,
                subtotal: 0,
                discountAmount: 0,
                taxAmount: 0,
                shippingAmount: 0,
                otherCharges: 0,
                roundOffAmount: 0,
                totalAmount: 0,
                paidAmount: 0,
                dueAmount: 0,
            };

        // =================================================
        // PAYMENT STATUS SUMMARY
        // =================================================

        const paymentStatusSummary =
            await PurchaseInvoice.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: "$paymentStatus",

                        count: {
                            $sum: 1,
                        },

                        amount: {
                            $sum: {
                                $ifNull: [
                                    "$totalAmount",
                                    0,
                                ],
                            },
                        },

                        paidAmount: {
                            $sum: {
                                $ifNull: [
                                    "$paidAmount",
                                    0,
                                ],
                            },
                        },

                        dueAmount: {
                            $sum: {
                                $ifNull: [
                                    "$dueAmount",
                                    0,
                                ],
                            },
                        },
                    },
                },

                {
                    $sort: {
                        _id: 1,
                    },
                },
            ]);

        // =================================================
        // FINAL RESPONSE
        // =================================================

        return res.status(200).json({
            success: true,

            data: {
                invoices,

                summary: {
                    totalInvoices:
                        summary.totalInvoices,

                    subtotal:
                        summary.subtotal,

                    discountAmount:
                        summary.discountAmount,

                    taxAmount:
                        summary.taxAmount,

                    shippingAmount:
                        summary.shippingAmount,

                    otherCharges:
                        summary.otherCharges,

                    roundOffAmount:
                        summary.roundOffAmount,

                    totalAmount:
                        summary.totalAmount,

                    paidAmount:
                        summary.paidAmount,

                    dueAmount:
                        summary.dueAmount,
                },

                paymentStatusSummary:
                    paymentStatusSummary.map(
                        (item) => ({
                            paymentStatus:
                                item._id,

                            count:
                                item.count,

                            amount:
                                item.amount,

                            paidAmount:
                                item.paidAmount,

                            dueAmount:
                                item.dueAmount,
                        })
                    ),
            },

            pagination: {
                total,
                page: currentPage,
                limit: currentLimit,
                totalPages:
                    Math.ceil(
                        total / currentLimit
                    ),
            },
        });

    } catch (error) {
        console.error(
            "Get Purchase Report Error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch purchase report.",
            error: error.message,
        });
    }
};

// =====================================================
// GET INVENTORY / STOCK REPORT
// =====================================================

const getInventoryReport = async (req, res) => {
    try {
        const {
            company,
            branch,
            warehouse,
            product,
            category,
            lowStock,
            outOfStock,
            overStock,
            page = 1,
            limit = 20,
        } = req.query;

        // =================================================
        // VALIDATION
        // =================================================

        if (!company) {
            return res.status(400).json({
                success: false,
                message: "Company is required.",
            });
        }

        if (!mongoose.Types.ObjectId.isValid(company)) {
            return res.status(400).json({
                success: false,
                message: "Invalid company ID.",
            });
        }

        if (
            branch &&
            !mongoose.Types.ObjectId.isValid(branch)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid branch ID.",
            });
        }

        if (
            warehouse &&
            !mongoose.Types.ObjectId.isValid(warehouse)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid warehouse ID.",
            });
        }

        if (
            product &&
            !mongoose.Types.ObjectId.isValid(product)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid product ID.",
            });
        }

        if (
            category &&
            !mongoose.Types.ObjectId.isValid(category)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid category ID.",
            });
        }

        // =================================================
        // PAGINATION
        // =================================================

        const currentPage = Math.max(
            Number(page) || 1,
            1
        );

        const currentLimit = Math.min(
            Math.max(Number(limit) || 20, 1),
            100
        );

        const skip =
            (currentPage - 1) * currentLimit;

        // =================================================
        // BASE MATCH
        // =================================================

        const match = {
            company:
                new mongoose.Types.ObjectId(company),

            isActive: true,
        };

        if (branch) {
            match.branch =
                new mongoose.Types.ObjectId(branch);
        }

        if (warehouse) {
            match.warehouse =
                new mongoose.Types.ObjectId(
                    warehouse
                );
        }

        if (product) {
            match.product =
                new mongoose.Types.ObjectId(product);
        }

        // =================================================
        // BASE PIPELINE
        // =================================================

        const pipeline = [
            {
                $match: match,
            },

            // =============================================
            // PRODUCT LOOKUP
            // =============================================

            {
                $lookup: {
                    from: "products",
                    localField: "product",
                    foreignField: "_id",
                    as: "productData",
                },
            },

            {
                $unwind: "$productData",
            },

            // =============================================
            // WAREHOUSE LOOKUP
            // =============================================

            {
                $lookup: {
                    from: "warehouses",
                    localField: "warehouse",
                    foreignField: "_id",
                    as: "warehouseData",
                },
            },

            {
                $unwind: "$warehouseData",
            },

            // =============================================
            // CATEGORY LOOKUP
            // =============================================

            {
                $lookup: {
                    from: "categories",
                    localField:
                        "productData.category",
                    foreignField: "_id",
                    as: "categoryData",
                },
            },

            {
                $unwind: {
                    path: "$categoryData",
                    preserveNullAndEmptyArrays: true,
                },
            },

            // =============================================
            // CATEGORY FILTER
            // =============================================

            ...(category
                ? [
                      {
                          $match: {
                              "productData.category":
                                  new mongoose.Types.ObjectId(
                                      category
                                  ),
                          },
                      },
                  ]
                : []),

            // =============================================
            // CALCULATED VALUES
            // =============================================

            {
                $addFields: {
                    availableQuantity: {
                        $subtract: [
                            "$quantity",
                            "$reservedQuantity",
                        ],
                    },

                    stockValue: {
                        $multiply: [
                            "$quantity",
                            {
                                $ifNull: [
                                    "$productData.purchasePrice",
                                    0,
                                ],
                            },
                        ],
                    },

                    sellingValue: {
                        $multiply: [
                            "$quantity",
                            {
                                $ifNull: [
                                    "$productData.sellingPrice",
                                    0,
                                ],
                            },
                        ],
                    },

                    potentialProfit: {
                        $subtract: [
                            {
                                $multiply: [
                                    "$quantity",
                                    {
                                        $ifNull: [
                                            "$productData.sellingPrice",
                                            0,
                                        ],
                                    },
                                ],
                            },

                            {
                                $multiply: [
                                    "$quantity",
                                    {
                                        $ifNull: [
                                            "$productData.purchasePrice",
                                            0,
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                },
            },

            // =============================================
            // STOCK STATUS
            // =============================================

            {
                $addFields: {
                    stockStatus: {
                        $switch: {
                            branches: [
                                {
                                    case: {
                                        $lte: [
                                            "$availableQuantity",
                                            0,
                                        ],
                                    },

                                    then:
                                        "OUT_OF_STOCK",
                                },

                                {
                                    case: {
                                        $and: [
                                            {
                                                $gt: [
                                                    "$minimumStock",
                                                    0,
                                                ],
                                            },

                                            {
                                                $lte: [
                                                    "$availableQuantity",
                                                    "$minimumStock",
                                                ],
                                            },
                                        ],
                                    },

                                    then:
                                        "LOW_STOCK",
                                },

                                {
                                    case: {
                                        $and: [
                                            {
                                                $gt: [
                                                    "$maximumStock",
                                                    0,
                                                ],
                                            },

                                            {
                                                $gt: [
                                                    "$quantity",
                                                    "$maximumStock",
                                                ],
                                            },
                                        ],
                                    },

                                    then:
                                        "OVER_STOCK",
                                },
                            ],

                            default: "NORMAL",
                        },
                    },
                },
            },
        ];

        // =================================================
        // STOCK STATUS FILTER
        // =================================================

        if (lowStock === "true") {
            pipeline.push({
                $match: {
                    stockStatus: "LOW_STOCK",
                },
            });
        }

        if (outOfStock === "true") {
            pipeline.push({
                $match: {
                    stockStatus: "OUT_OF_STOCK",
                },
            });
        }

        if (overStock === "true") {
            pipeline.push({
                $match: {
                    stockStatus: "OVER_STOCK",
                },
            });
        }

        // =================================================
        // TOTAL COUNT
        // =================================================

        const countPipeline = [
            ...pipeline,

            {
                $count: "total",
            },
        ];

        const countResult =
            await Stock.aggregate(
                countPipeline
            );

        const total =
            countResult.length > 0
                ? countResult[0].total
                : 0;

        // =================================================
        // REPORT DATA
        // =================================================

        const reportPipeline = [
            ...pipeline,

            {
                $sort: {
                    "productData.name": 1,
                    "warehouseData.name": 1,
                },
            },

            {
                $skip: skip,
            },

            {
                $limit: currentLimit,
            },

            // =============================================
            // FINAL PROJECT
            // =============================================

            {
                $project: {
                    _id: 1,

                    company: 1,

                    branch: 1,

                    warehouse: {
                        _id:
                            "$warehouseData._id",

                        name:
                            "$warehouseData.name",

                        code:
                            "$warehouseData.code",
                    },

                    product: {
                        _id:
                            "$productData._id",

                        name:
                            "$productData.name",

                        sku:
                            "$productData.sku",

                        barcode:
                            "$productData.barcode",

                        purchasePrice:
                            "$productData.purchasePrice",

                        sellingPrice:
                            "$productData.sellingPrice",
                    },

                    category: {
                        _id:
                            "$categoryData._id",

                        name:
                            "$categoryData.name",
                    },

                    quantity: 1,

                    reservedQuantity: 1,

                    availableQuantity: 1,

                    minimumStock: 1,

                    maximumStock: 1,

                    stockStatus: 1,

                    stockValue: 1,

                    sellingValue: 1,

                    potentialProfit: 1,

                    lastStockUpdate: 1,

                    createdAt: 1,

                    updatedAt: 1,
                },
            },
        ];

        const stocks =
            await Stock.aggregate(
                reportPipeline
            );

        // =================================================
        // SUMMARY
        // =================================================

        const summaryPipeline = [
            ...pipeline,

            {
                $group: {
                    _id: null,

                    totalItems: {
                        $sum: 1,
                    },

                    totalQuantity: {
                        $sum: "$quantity",
                    },

                    totalReservedQuantity: {
                        $sum: "$reservedQuantity",
                    },

                    totalAvailableQuantity: {
                        $sum: "$availableQuantity",
                    },

                    totalStockValue: {
                        $sum: "$stockValue",
                    },

                    totalSellingValue: {
                        $sum: "$sellingValue",
                    },

                    totalPotentialProfit: {
                        $sum: "$potentialProfit",
                    },

                    lowStockItems: {
                        $sum: {
                            $cond: [
                                {
                                    $eq: [
                                        "$stockStatus",
                                        "LOW_STOCK",
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },

                    outOfStockItems: {
                        $sum: {
                            $cond: [
                                {
                                    $eq: [
                                        "$stockStatus",
                                        "OUT_OF_STOCK",
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },

                    overStockItems: {
                        $sum: {
                            $cond: [
                                {
                                    $eq: [
                                        "$stockStatus",
                                        "OVER_STOCK",
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },

                    normalStockItems: {
                        $sum: {
                            $cond: [
                                {
                                    $eq: [
                                        "$stockStatus",
                                        "NORMAL",
                                    ],
                                },
                                1,
                                0,
                            ],
                        },
                    },
                },
            },
        ];

        const summaryResult =
            await Stock.aggregate(
                summaryPipeline
            );

        const summary =
            summaryResult.length > 0
                ? summaryResult[0]
                : {
                      totalItems: 0,

                      totalQuantity: 0,

                      totalReservedQuantity: 0,

                      totalAvailableQuantity: 0,

                      totalStockValue: 0,

                      totalSellingValue: 0,

                      totalPotentialProfit: 0,

                      lowStockItems: 0,

                      outOfStockItems: 0,

                      overStockItems: 0,

                      normalStockItems: 0,
                  };

        // =================================================
        // FINAL RESPONSE
        // =================================================

        return res.status(200).json({
            success: true,

            data: {
                stocks,

                summary: {
                    totalItems:
                        summary.totalItems,

                    totalQuantity:
                        summary.totalQuantity,

                    totalReservedQuantity:
                        summary.totalReservedQuantity,

                    totalAvailableQuantity:
                        summary.totalAvailableQuantity,

                    totalStockValue:
                        summary.totalStockValue,

                    totalSellingValue:
                        summary.totalSellingValue,

                    totalPotentialProfit:
                        summary.totalPotentialProfit,

                    lowStockItems:
                        summary.lowStockItems,

                    outOfStockItems:
                        summary.outOfStockItems,

                    overStockItems:
                        summary.overStockItems,

                    normalStockItems:
                        summary.normalStockItems,
                },
            },

            pagination: {
                total,

                page: currentPage,

                limit: currentLimit,

                totalPages:
                    Math.ceil(
                        total / currentLimit
                    ),
            },
        });

    } catch (error) {
        console.error(
            "Get Inventory Report Error:",
            error
        );

        return res.status(500).json({
            success: false,

            message:
                "Failed to fetch inventory report.",

            error: error.message,
        });
    }
};

// =====================================================
// GET EXPENSE REPORT
// =====================================================

const getExpenseReport = async (req, res) => {
    try {
        const {
            company,
            branch,
            category,
            supplier,
            status,
            paymentMethod,
            fromDate,
            toDate,
            page = 1,
            limit = 20,
        } = req.query;

        // =================================================
        // VALIDATION
        // =================================================

        if (!company) {
            return res.status(400).json({
                success: false,
                message: "Company is required.",
            });
        }

        if (!mongoose.Types.ObjectId.isValid(company)) {
            return res.status(400).json({
                success: false,
                message: "Invalid company ID.",
            });
        }

        if (
            branch &&
            !mongoose.Types.ObjectId.isValid(branch)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid branch ID.",
            });
        }

        if (
            category &&
            !mongoose.Types.ObjectId.isValid(category)
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid expense category ID.",
            });
        }

        if (
            supplier &&
            !mongoose.Types.ObjectId.isValid(supplier)
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid supplier ID.",
            });
        }

        // =================================================
        // PAGINATION
        // =================================================

        const currentPage = Math.max(
            Number(page) || 1,
            1
        );

        const currentLimit = Math.min(
            Math.max(Number(limit) || 20, 1),
            100
        );

        const skip =
            (currentPage - 1) * currentLimit;

        // =================================================
        // BASE MATCH
        // =================================================

        const match = {
            company:
                new mongoose.Types.ObjectId(company),
        };

        if (branch) {
            match.branch =
                new mongoose.Types.ObjectId(branch);
        }

        if (category) {
            match.category =
                new mongoose.Types.ObjectId(category);
        }

        if (supplier) {
            match.supplier =
                new mongoose.Types.ObjectId(supplier);
        }

        // =================================================
        // STATUS FILTER
        // =================================================

        if (status) {
            const allowedStatuses = [
                "DRAFT",
                "PENDING",
                "APPROVED",
                "REJECTED",
                "PAID",
                "CANCELLED",
            ];

            if (!allowedStatuses.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid expense status.",
                });
            }

            match.status = status;
        }

        // =================================================
        // PAYMENT METHOD FILTER
        // =================================================

        if (paymentMethod) {
            const allowedPaymentMethods = [
                "CASH",
                "BANK_TRANSFER",
                "UPI",
                "CARD",
                "CHEQUE",
                "OTHER",
            ];

            if (
                !allowedPaymentMethods.includes(
                    paymentMethod
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid payment method.",
                });
            }

            match.paymentMethod =
                paymentMethod;
        }

        // =================================================
        // DATE FILTER
        // =================================================

        if (fromDate || toDate) {
            match.expenseDate = {};

            if (fromDate) {
                const startDate =
                    new Date(fromDate);

                if (isNaN(startDate.getTime())) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "Invalid fromDate.",
                    });
                }

                startDate.setHours(
                    0,
                    0,
                    0,
                    0
                );

                match.expenseDate.$gte =
                    startDate;
            }

            if (toDate) {
                const endDate =
                    new Date(toDate);

                if (isNaN(endDate.getTime())) {
                    return res.status(400).json({
                        success: false,
                        message:
                            "Invalid toDate.",
                    });
                }

                endDate.setHours(
                    23,
                    59,
                    59,
                    999
                );

                match.expenseDate.$lte =
                    endDate;
            }
        }

        // =================================================
        // TOTAL COUNT
        // =================================================

        const total =
            await Expense.countDocuments(match);

        // =================================================
        // GET REPORT DATA
        // =================================================

        const expenses =
            await Expense.find(match)
                .populate(
                    "category",
                    "name code parentCategory"
                )
                .populate(
                    "branch",
                    "name code"
                )
                .populate(
                    "supplier",
                    "name email phone"
                )
                .populate(
                    "approvedBy",
                    "name email"
                )
                .populate(
                    "paidBy",
                    "name email"
                )
                .populate(
                    "createdBy",
                    "name email"
                )
                .populate(
                    "updatedBy",
                    "name email"
                )
                .sort({
                    expenseDate: -1,
                    createdAt: -1,
                })
                .skip(skip)
                .limit(currentLimit)
                .lean();

        // =================================================
        // OVERALL SUMMARY
        // =================================================

        const summaryResult =
            await Expense.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: null,

                        totalExpenses: {
                            $sum: 1,
                        },

                        totalAmount: {
                            $sum: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },

                        averageAmount: {
                            $avg: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },

                        maximumAmount: {
                            $max: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },

                        minimumAmount: {
                            $min: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },
                    },
                },
            ]);

        const summary =
            summaryResult[0] || {
                totalExpenses: 0,
                totalAmount: 0,
                averageAmount: 0,
                maximumAmount: 0,
                minimumAmount: 0,
            };

        // =================================================
        // STATUS SUMMARY
        // =================================================

        const statusSummary =
            await Expense.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: "$status",

                        count: {
                            $sum: 1,
                        },

                        amount: {
                            $sum: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },
                    },
                },

                {
                    $sort: {
                        _id: 1,
                    },
                },
            ]);

        // =================================================
        // PAYMENT METHOD SUMMARY
        // =================================================

        const paymentMethodSummary =
            await Expense.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: "$paymentMethod",

                        count: {
                            $sum: 1,
                        },

                        amount: {
                            $sum: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },
                    },
                },

                {
                    $sort: {
                        _id: 1,
                    },
                },
            ]);

        // =================================================
        // CATEGORY SUMMARY
        // =================================================

        const categorySummary =
            await Expense.aggregate([
                {
                    $match: match,
                },

                {
                    $group: {
                        _id: "$category",

                        count: {
                            $sum: 1,
                        },

                        amount: {
                            $sum: {
                                $ifNull: [
                                    "$amount",
                                    0,
                                ],
                            },
                        },
                    },
                },

                {
                    $lookup: {
                        from: "expensecategories",

                        localField: "_id",

                        foreignField: "_id",

                        as: "categoryData",
                    },
                },

                {
                    $unwind: {
                        path: "$categoryData",

                        preserveNullAndEmptyArrays:
                            true,
                    },
                },

                {
                    $project: {
                        _id: 0,

                        category: "$_id",

                        categoryName:
                            "$categoryData.name",

                        count: 1,

                        amount: 1,
                    },
                },

                {
                    $sort: {
                        amount: -1,
                    },
                },
            ]);

        // =================================================
        // FINAL RESPONSE
        // =================================================

        return res.status(200).json({
            success: true,

            data: {
                expenses,

                summary: {
                    totalExpenses:
                        summary.totalExpenses,

                    totalAmount:
                        summary.totalAmount,

                    averageAmount:
                        summary.averageAmount || 0,

                    maximumAmount:
                        summary.maximumAmount || 0,

                    minimumAmount:
                        summary.minimumAmount || 0,
                },

                statusSummary:
                    statusSummary.map(
                        (item) => ({
                            status:
                                item._id,

                            count:
                                item.count,

                            amount:
                                item.amount,
                        })
                    ),

                paymentMethodSummary:
                    paymentMethodSummary.map(
                        (item) => ({
                            paymentMethod:
                                item._id,

                            count:
                                item.count,

                            amount:
                                item.amount,
                        })
                    ),

                categorySummary,
            },

            pagination: {
                total,

                page: currentPage,

                limit: currentLimit,

                totalPages:
                    Math.ceil(
                        total / currentLimit
                    ),
            },
        });

    } catch (error) {
        console.error(
            "Get Expense Report Error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch expense report.",
            error: error.message,
        });
    }
};

// =====================================================
// EXPORT
// =====================================================

module.exports = {
    getSalesReport,
    getPurchaseReport,
    getInventoryReport,
    getExpenseReport,
};