const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema(
    {
        // =====================================
        // BASIC DETAILS
        // =====================================
        name: {
            type: String,
            required: [true, "Name is required"],
            trim: true,
            minlength: 2,
            maxlength: 100,
        },

        email: {
            type: String,
            required: [true, "Email is required"],
            unique: true,
            lowercase: true,
            trim: true,
        },

        phone: {
            type: String,
            trim: true,
            default: "",
        },

        password: {
            type: String,
            required: [true, "Password is required"],
            minlength: 6,
            select: false,
        },

        // =====================================
        // EMPLOYEE DETAILS
        // =====================================
        employeeId: {
            type: String,
            unique: true,
            sparse: true,
            trim: true,
            uppercase: true,
            default: null,
        },

      department: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Department",
    default: null,
},

designation: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Designation",
    default: null,
},

        joiningDate: {
            type: Date,
            default: null,
        },

        dateOfBirth: {
            type: Date,
            default: null,
        },

        gender: {
            type: String,
            enum: ["MALE", "FEMALE", "OTHER", ""],
            default: "",
        },

        address: {
            street: {
                type: String,
                trim: true,
                default: "",
            },

            city: {
                type: String,
                trim: true,
                default: "",
            },

            state: {
                type: String,
                trim: true,
                default: "",
            },

            country: {
                type: String,
                trim: true,
                default: "India",
            },

            pincode: {
                type: String,
                trim: true,
                default: "",
            },
        },

        // =====================================
        // ERP ORGANIZATION
        // =====================================
        company: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Company",
            default: null,
        },

        branch: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Branch",
            default: null,
        },

        // =====================================
        // ROLE & PERMISSIONS
        // =====================================
        role: {
            type: String,
            enum: [
                "SUPER_ADMIN",
                "ADMIN",
                "MANAGER",
                "HR",
                "SALES",
                "PURCHASE",
                "INVENTORY",
                "ACCOUNTANT",
                "EMPLOYEE",
            ],
            default: "EMPLOYEE",
        },

        permissions: {
            type: [String],
            default: [],
        },

        // =====================================
        // PROFILE
        // =====================================
        profileImage: {
            type: String,
            default: "",
        },

        isActive: {
            type: Boolean,
            default: true,
        },

        lastLogin: {
            type: Date,
            default: null,
        },
    },
    {
        timestamps: true,
    }
);


// =====================================
// PASSWORD HASH
// =====================================
userSchema.pre("save", async function () {
    if (!this.isModified("password")) {
        return;
    }

    const salt = await bcrypt.genSalt(10);

    this.password = await bcrypt.hash(
        this.password,
        salt
    );
});


// =====================================
// PASSWORD COMPARE
// =====================================
userSchema.methods.comparePassword = async function (
    enteredPassword
) {
    return await bcrypt.compare(
        enteredPassword,
        this.password
    );
};


const User = mongoose.model("User", userSchema);

module.exports = User;