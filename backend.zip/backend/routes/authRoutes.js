const express = require("express");
const {
    requirePermission,
} = require("../middleware/permissionMiddleware");
const {
    registerUser,
    loginUser,
} = require("../controllers/authController");

const { protect } = require("../middleware/authMiddleware");
const { authorizeRoles } = require("../middleware/roleMiddleware");

const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginUser);

// Any logged-in user
router.get("/me", protect, (req, res) => {
    res.status(200).json({
        success: true,
        message: "Authenticated user details",
        user: req.user,
    });
});
router.get(
    "/permission-test",
    protect,
    requirePermission("reports.view"),
    (req, res) => {
        res.status(200).json({
            success: true,
            message: "Permission verified successfully! 🔐",
            permission: "reports.view",
            user: {
                name: req.user.name,
                role: req.user.role,
            },
        });
    }
);
// Only Admin
router.get(
    "/admin-test",
    protect,
    authorizeRoles("ADMIN", "SUPER_ADMIN"),
    (req, res) => {
        res.status(200).json({
            success: true,
            message: "Welcome Admin! 🔐",
            user: req.user,
        });
    }
);
module.exports = router;