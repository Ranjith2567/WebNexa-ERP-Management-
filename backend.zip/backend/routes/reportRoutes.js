const express = require("express");

const {
    getSalesReport,
    getPurchaseReport,
    getInventoryReport,
    getExpenseReport,
} = require("../controllers/reportController");

const {
    protect,
} = require("../middleware/authMiddleware");

const {
    authorizeRoles,
} = require("../middleware/roleMiddleware");

const router = express.Router();

// =====================================================
// AUTHENTICATION
// =====================================================

router.use(protect);

// =====================================================
// AUTHORIZATION
// =====================================================

router.use(
    authorizeRoles("SUPER_ADMIN")
);

// =====================================================
// SALES REPORT
// =====================================================

router.get(
    "/sales",
    getSalesReport
);

// =====================================================
// PURCHASE REPORT
// =====================================================

router.get(
    "/purchases",
    getPurchaseReport
);

// =====================================================
// INVENTORY / STOCK REPORT
// =====================================================

router.get(
    "/inventory",
    getInventoryReport
);

// =====================================================
// EXPENSE REPORT
// =====================================================

router.get(
    "/expenses",
    getExpenseReport
);

// =====================================================
// EXPORT ROUTER
// =====================================================

module.exports = router;